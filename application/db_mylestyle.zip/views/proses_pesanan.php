<div class="container-fluid">
	<div class="alert alert-success">
	<p class="text-center align-middle">Mohon Bersabar Pesanan Sedang di Proses</p>
	</div>
</div>